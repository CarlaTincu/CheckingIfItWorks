﻿using SecondCode_course_.HR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondCode_course_.Accounting
{

    internal class Customer : Employee
    {
        private string customerId;
        private string customerName;

        public Customer(string firstName, string lastName, string email, string phone, double? wage, double? hourlyRate) : base(firstName, lastName, email, phone, wage, hourlyRate)
        {
        }

        public string CustomerId
        {
            get { return customerId; }
            set { customerId = value; }
        }
        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }
    }
}
