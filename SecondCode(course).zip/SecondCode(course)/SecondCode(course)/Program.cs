﻿// See https://aka.ms/new-console-template for more information
using SecondCode_course_;
using SecondCode_course_.Accounting;
using SecondCode_course_.HR;
using System.Collections.Immutable;
using System.Reflection.Metadata.Ecma335;

/*Employee employee = new Employee("Ana", "Maria", "ana_maria@gmail.com", "0752805299", EmployeeType.Manager,10,20);
Employee jerry = new Employee("Anaaaaa", "Maraaaaaaia", "anaaaaaaaaaaa_maria@gmail.com", "0752854399", EmployeeType.StoreManager,30,14);
string employeeAsJson = employee.ConvertToJson();
Console.WriteLine(employeeAsJson);



SecondCode_course_.Accounting.Customer customer = new SecondCode_course_.Accounting.Customer();


List<Employee> list = new List<Employee>();
for(int i = 0;i < 1000000;i++)
{
    Employee randomEmployee = new Employee(Guid.NewGuid().ToString(),Guid.NewGuid().ToString(),Guid.NewGuid().ToString(), Guid.NewGuid().ToString(),EmployeeType.StoreManager,null,null);
    randomEmployee.displayEmployessDetails();
    if( i == 6)
    {
        break;
    }
    list.Add(randomEmployee);
   
}
Console.WriteLine(GC.GetTotalMemory(false));
list.Clear();
list = null;
GC.Collect();
Console.WriteLine(GC.GetTotalMemory(false));
//Console.ReadLine();

int[] list1 = new int[4] {3,4,5,5};
*/




/*int lenght = int.Parse(Console.ReadLine());

int[] employeesId =  new int[lenght];


for(int index = 0;  index < lenght; index++)
{
    Console.WriteLine($"ID NUMBER {index+1}");
    int id = int.Parse(Console.ReadLine());
    employeesId[index] = id;
}

for (int index = 0; index < lenght; index++)
{
    Console.WriteLine($"{index + 1} : {employeesId[index]}");
}
Array.Sort( employeesId );
Console.WriteLine("THE ARRAY SORTED: \n\n");
for (int index = 0; index < lenght; index++)
{
    Console.WriteLine($"{index + 1} : {employeesId[index]}");
}

int[] ArrayCopy = new int[lenght];
employeesId.CopyTo( ArrayCopy, 0 );
Array.Reverse(ArrayCopy);
Console.WriteLine("ARRAY COPIED AND REVERSED:");
for (int index = 0; index < lenght; index++)
{
    Console.WriteLine($"{index + 1} : {ArrayCopy[index]}");
}
*/
/*Employee a = new Employee("A", "M", "anaaaaaaaaaaa_maria1@gmail.com", "0752854399",  30, 14);
Employee b = new Employee("B", "A", "anaaaaaaaaaaa_maria2@gmail.com", "0752854398",  25, 13);
Employee c = new Employee("C", "N", "anaaaaaaaaaaa_maria3@gmail.com", "0752854397",  30, 45);
Employee d = new Employee("D", "E", "anaaaaaaaaaaa_maria4@gmail.com", "0752854396",  30, 69);

Employee[] listOfEmployees = new Employee[] { a, b, c, d };
foreach(Employee employee in listOfEmployees)
{
    employee.displayEmployessDetails();
    var numberOffHoursWorked = new Random().Next(25); //random integer number 
    employee.PerformWork(numberOffHoursWorked);
}

a.FirstName = "FLOAREA";



foreach (Employee employee in listOfEmployees)
{
    employee.displayEmployessDetails();
}

Console.WriteLine(a.ConvertToJson());


Manager mary = new Manager("Floarea", "Florentina", "xxxxxxxxxxx@lateralgroup.com", "078998565", 1000, 244);
Console.WriteLine(mary.ConvertToJson());
mary.PerformWorkRandom();
mary.displayEmployessDetails();
mary.Wwage();

Console.WriteLine(mary.ConvertToJson());


Customer customer = new Customer("elena", "arbore", "elenuta@yahoo.com", "07898292748", 200, 10);

a.getBonus();
mary.getBonus();
customer.getBonus();*/

Utilities.CheckIfTheFileExists();
Console.WriteLine("PRESS 3 TO ADD EMPLOYEES");
Console.WriteLine("PRESS 2");
Console.WriteLine("PRESS 3");
Console.WriteLine("PRESS 4");
Console.WriteLine("PRESS 9");
Console.WriteLine("INTRODUCE THE NUMBER : ");
Employee a = new Employee("A", "M", "anaaaaaaaaaaa_maria1@gmail.com", "0752854399", 30, 14);
Employee b = new Employee("B", "A", "anaaaaaaaaaaa_maria2@gmail.com", "0752854398", 25, 13);
Employee c = new Employee("C", "N", "anaaaaaaaaaaa_maria3@gmail.com", "0752854397", 30, 45);
Employee d = new Employee("D", "E", "anaaaaaaaaaaa_maria4@gmail.com", "0752854396", 30, 69);

List<Employee> employees = new List<Employee>();

string key = Console.ReadLine();
switch (key)
{
    
    case "1":
        //Utilities.RegisterEmployees();
        break;
    case "2":
        //Utilities.VisualizeAllEmployees();
        break;
    case "3":
        
        int x = 10;
        
        string fName, lName, email = "", phone = "";
        double wage = 0, hoursWorked = 1;
        Console.WriteLine("Introduce the first name: ");
        fName = Console.ReadLine();
        Console.WriteLine("Introduce the last name: ");
        lName = Console.ReadLine();
        Employee newEmployee = new Employee(fName, lName, email, phone, wage, hoursWorked);
        employees.Add(newEmployee);
        Utilities.SaveEmployees(employees);
        break;
  
    case "4":
        //Utilities.LoadEmployees();
        break;
    case "9":
        break;
    default:
        Console.WriteLine("Invalid solution.");
        break;
}

