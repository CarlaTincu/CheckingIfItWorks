﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondCode_course_.HR
{
    public class Employee
    {
        private string firstName;
        public string lastName;
        public string email;
        public string phone;
        public int numberOfHoursWorked;
        public double wage;
        public double? hourlyRate;
        public DateTime birthDay;
        const int minimalHoursWorkedUnit = 1;
        public static double txtRate = 0.15;
        private string? name;
        private string? lname;
        private Guid guid1;
        private Guid guid2;
        private int v1;
        private int v2;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        public double? HourlyRate
        {
            get {  return hourlyRate; }
            private set { hourlyRate = value; }
        }
        public double Wage
        {
            get { return wage;}
            protected set { wage = value; }
        }
        public Employee(string firstName, string lastName, string email, string phone, double? wage, double? hourlyRate)
        {
            this.FirstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.phone = phone;
            birthDay = DateTime.Now.AddDays(10);
           
           // ReceiveWage(true);
        }

        public Employee(string? name, string? lname, Guid guid1, Guid guid2, int v1, int v2)
        {
            this.name = name;
            this.lname = lname;
            this.guid1 = guid1;
            this.guid2 = guid2;
            this.v1 = v1;
            this.v2 = v2;
        }

        public void PerformWork()
        {
            PerformWork(minimalHoursWorkedUnit);
           
        }

        public void PerformWork(int numberOfHours)
        {
            numberOfHoursWorked += numberOfHours;
            Console.WriteLine($"\n\n{firstName} {lastName} has worked for {numberOfHoursWorked}");
        }
        public double WagePerform()
        {
            if (wage % 2 == 1)
                return wage;
            return 0;
        }
        public void PerformWorkRandom()
        {
            numberOfHoursWorked = new Random().Next(100);
            Console.WriteLine($"\n\n{firstName} {lastName} has worked for {numberOfHoursWorked}");
        }
        /*public void ReceiveWage(bool resetHours = true)
        {
            //wage = numberOfHoursWorked * hourlyRate;
            Console.WriteLine($"{firstName} {lastName} has received a wage of {wage} for {numberOfHoursWorked}");
            if (resetHours)
            {
                numberOfHoursWorked = 0;
            }
            //return wage;
            if (employeeType == EmployeeType.Manager)
            {
                Console.WriteLine($"An extra was added on the wage since {firstName} is a manager! ");
            }
            else Console.WriteLine($"{firstName} NU PRIMESTE NIMIC!!");
        }*/
        public void displayEmployessDetails()
        {
            Console.WriteLine($"First name : {firstName}, Last name : {lastName}, Phone : {phone}, birthday : {birthDay.ToShortDateString()}");
        }
        public string ConvertToJson()
        {
            string json = JsonConvert.SerializeObject(this);
            return json;
        }
        public virtual void getBonus()
        {
            Console.WriteLine($"{firstName} {lastName} has a generic bonus of 100!");
        }
    }
}
