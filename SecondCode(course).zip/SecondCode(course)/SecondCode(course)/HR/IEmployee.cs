﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondCode_course_.HR
{
    internal class IEmployee
    {
    }
}
