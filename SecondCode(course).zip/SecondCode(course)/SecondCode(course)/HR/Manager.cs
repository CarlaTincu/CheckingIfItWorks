﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondCode_course_.HR
{
    internal class Manager : Employee
    {
        public Manager(string firstName, string lastName, string email, string phone, double? wage, double? hourlyRate) : base(firstName, lastName, email, phone, wage, hourlyRate)
        {
        }
        public void Wwage()
        {
            Wage += 10;
        }
        public override void getBonus()
        {
            if(Wage > 50)
            {
                Console.WriteLine($"Manager {FirstName} has a bonus of  50%!");
            }
            else
            {
                Console.WriteLine($"Manager {FirstName} has a bonus of  0%!");
            }
        }
    }
}
