﻿using Microsoft.VisualBasic;
using SecondCode_course_.HR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace SecondCode_course_
{
    internal class Utilities
    {
        private static string directory = @"C:\Users\carla\source\repos\SecondCode(course)\SecondCode(course)";
        private static string fileName = "employees.txt";
        internal static void CheckIfTheFileExists()
        {
            string path = $"{directory}{fileName}";
            bool existingFile = File.Exists(path) ;
            if (existingFile) 
            {
                Console.WriteLine("THE FILE EXISTS!");
            }
            else
            {
                if(!Directory.Exists(directory)) 
                {
                    Directory.CreateDirectory(directory);
                    Console.BackgroundColor = ConsoleColor.Blue;
                    Console.WriteLine("Directory is ready to save files!");
                    Console.ResetColor();
                }
                else
                {
                    Console.BackgroundColor= ConsoleColor.Green;
                    Console.WriteLine("THE DIRECTORY ALREADY EXISTS!");
                    Console.ResetColor();
                }
            }
        }
        internal static void RegisterEmployees(List<Employee> employees)
        {

        }
        internal static void VisualizeAllEmployees(List<Employee> employees)
        {
            for(int i = 0;i<employees.Count;i++)
            {
                employees[i].displayEmployessDetails();
            }
        }
        internal static void LoadEmployees(List<Employee> employees)
        {

        }

        internal static void SaveEmployees(List<Employee> employees)
        {
            string path = $"{directory}\\{fileName}";
            StringBuilder sb = new StringBuilder();
            foreach (Employee employee in employees)
            {
                sb.Append($"First Name: {employee.FirstName}");
                sb.Append(" ");
                sb.Append($"Last Name: {employee.lastName}");

                sb.Append(Environment.NewLine);
            }
            File.WriteAllText(path, sb.ToString());
            Console.BackgroundColor = ConsoleColor.Green;
            Console.WriteLine("EMPLOYEE ADDED SUCCESFULLY");
            Console.ResetColor();
        }
    }
}
