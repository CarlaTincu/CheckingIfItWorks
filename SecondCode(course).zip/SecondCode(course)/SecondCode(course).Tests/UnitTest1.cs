using SecondCode_course_.HR;

namespace SecondCode_course_.Tests
{
    public class EmployeeTest
    {
        [Fact]
        public void PerformWork_Adds_NumberOfHours()
        {

            //arrange
            Employee employee = new Employee("A", "M", "anaaaaaaaaaaa_maria1@gmail.com", "0752854399", 30, 14);
            int numberOfHours = 6;

            //act
            employee.PerformWork(numberOfHours);

            //assert
            Assert.Equal(numberOfHours, employee.numberOfHoursWorked);
        }
        [Fact]
        public void PerformWage()
        {
            Employee employee = new Employee("A", "M", "anaaaaaaaaaaa_maria1@gmail.com", "0752854399", 30, 14);
            employee.wage = 3;

            Assert.Equal(employee.wage, employee.WagePerform());
        }
    }
}